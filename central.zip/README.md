# [KPA | Central](https://isaac2ngeno5.github.io/central)

![LOGO](https://github.com/Isaac2Ngeno5/central/blob/master/assets/img/logo.png)

This is sample demo for the kenya pharmaceutical association central branch

## Technologies used
* Javascript
* CSS
* HTML


